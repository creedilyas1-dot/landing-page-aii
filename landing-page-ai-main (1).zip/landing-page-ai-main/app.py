from flask import Flask, request, jsonify, render_template_string
from google.cloud import vision
import io

app = Flask(__name__)

client = vision.ImageAnnotatorClient()

@app.route('/')
def home():
    return '''
    <h2>Upload Product Image</h2>
    <form action="/upload" method="post" enctype="multipart/form-data">
        <input type="file" name="image">
        <button type="submit">Upload</button>
    </form>
    '''

@app.route('/upload', methods=['POST'])
def upload_image():
    file = request.files['image']
    content = file.read()

    image = vision.Image(content=content)
    response = client.label_detection(image=image)

    labels = response.label_annotations

    product_name = labels[0].description if labels else "Product"
    description = "This is a high quality product detected by AI."

    landing_page = generate_landing_page(product_name, description)

    return landing_page


def generate_landing_page(name, description):

    template = '''
    <html>
    <head>
    <title>{{name}}</title>
    </head>

    <body style="font-family:Arial;text-align:center">

    <h1>{{name}}</h1>

    <p>{{description}}</p>

    <button style="padding:15px;font-size:18px">
    Buy Now
    </button>

    </body>
    </html>
    '''

    return render_template_string(template, name=name, description=description)


if __name__ == '__main__':
    app.run(debug=True)
